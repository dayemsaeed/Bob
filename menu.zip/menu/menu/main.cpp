//Jiajie Wu
//cpts 122

#include "SFML/Graphics.hpp"
#include <iostream>
#include "Header.h"

int main(int argc, char** argv) 
{

	sf::RenderWindow window(sf::VideoMode(600, 600), "B.O.B Berserk Out Bob");
	
	Menu menu(window.getSize().x, window.getSize().y);

	sf::Texture texture;
	texture.loadFromFile("pic.jpg");

	sf::Sprite sprite(texture);

	sprite.setScale(1.f, 1.6f);
	sprite.setPosition(0.0f, 0.0f);

	while (window.isOpen()) 
	{
		sf::Event event;

		while (window.pollEvent(event)) 
		{
			switch (event.type) 
			{
			case sf::Event::KeyReleased:

				switch (event.key.code)
				{

				case sf::Keyboard::Up:
					menu.move_up();
					break;

				case sf::Keyboard::Down:
					menu.move_down();
					break;

				case sf::Keyboard::Return:

					switch (menu.get_pressed_item())
					{

					case 1:
						std::cout << "play button pressed" << std::endl;

						break;

					case 2:
						std::cout << "credits button pressed" << std::endl;

						break;

					case 3:
						window.close();

						break;
					}
					break;
				}
				break;

			case sf::Event::Closed:

				window.close();

				break;

			}
		} 

		window.clear();

		menu.draw(window);

		window.draw(sprite);

		window.display();

	}
}