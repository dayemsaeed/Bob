//Jiajie Wu
//cpts 122

#include "SFML/Graphics.hpp"

#define MAX_ITEMS 4
//#define The_Tiltle 1

class Menu
{
public:
	Menu(float width, float height);
	~Menu();

	void draw(sf::RenderWindow &window);
	void move_up();
	void move_down();
	int get_pressed_item() { return selected_item_index; }

private:
	int selected_item_index;
	sf::Font font;
	sf::Text menu[MAX_ITEMS];
	//sf::Text title[The_Tiltle];
};