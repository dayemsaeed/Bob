#pragma once
#include "TestMenu.h"

class Test
{
public:
	Test();
	~Test();
	void runTests();
protected:
private:
	sf::Sound scream;
	sf::SoundBuffer buffer;
	void testGravity();
	void testSound();
	void testCollisions();
	void testMovement();
	void testLoadMap();
};

bool checkCollides(sf::Sprite character, Platform all[], int &numPlat, int const &direction, float &speed);