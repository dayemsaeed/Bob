//Jiajie Wu
//cpts 122
#pragma once
#include "SFML/Graphics.hpp"
#include "SFML/Graphics/Font.hpp"
#include "SFML/Audio/Sound.hpp"
#include "SFML/Audio/SoundBuffer.hpp"
#include <iostream>
using std::cout;
#define MAX_ITEMS 7
//#define The_Tiltle 1

class Menu
{
public:
	Menu(float width, float height);
	~Menu();

	void draw(sf::RenderWindow &window);
	void move_up();
	void move_down();
	int get_pressed_item() { return selected_item_index; }
	void howTo();

private:
	int selected_item_index;
	sf::Font font;
	sf::Text menu[MAX_ITEMS];
	//sf::Text title[The_Tiltle];
};