#pragma once
#include "bob.h"
#include "wolves.h"

class Game
{
public:
	Game();
	~Game() {};
	void play();
	
protected:

private:
	sf::Sound scream;
	sf::SoundBuffer buffer;
};