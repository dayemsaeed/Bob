
#include "howTo.h"
howTo::howTo(float width, float height)
{
	if (!font.loadFromFile("arial.ttf"))
	{

	}
	else
	{
		menu[0].setFont(font);
		menu[0].setColor(sf::Color::Red);
		menu[0].setString("How To Menu");
		menu[0].setPosition(sf::Vector2f(width / 4.0, height / (HOW_TO_ITEMS + 1) * 4.0));

		menu[1].setFont(font);
		menu[1].setColor(sf::Color::White);
		menu[1].setString("Use the Arrow Keys");
		menu[1].setPosition(sf::Vector2f(width / 2.5, height / (HOW_TO_ITEMS + 1) * 4.5));

		menu[2].setFont(font);
		menu[2].setColor(sf::Color::White);
		menu[2].setString("Up to Jump");
		menu[2].setPosition(sf::Vector2f(width / 2.5, height / (HOW_TO_ITEMS + 1) * 5.0));

		menu[3].setFont(font);
		menu[3].setColor(sf::Color::White);
		menu[3].setString("Left to Move Left");
		menu[3].setPosition(sf::Vector2f(width / 2.5, height / (HOW_TO_ITEMS + 1) * 5.5));

		menu[4].setFont(font);
		menu[4].setColor(sf::Color::White);
		menu[4].setString("Right to Move Right");
		menu[4].setPosition(sf::Vector2f(width / 2.5, height / (HOW_TO_ITEMS + 1) * 6.0));

		menu[5].setFont(font);
		menu[5].setColor(sf::Color::White);
		menu[5].setString("Down does Nothing");
		menu[5].setPosition(sf::Vector2f(width / 2.5, height / (HOW_TO_ITEMS + 1) * 6.5));

		menu[6].setFont(font);
		menu[6].setColor(sf::Color::White);
		menu[6].setString("Enter for last menu");
		menu[6].setPosition(sf::Vector2f(width / 2.5, height / (HOW_TO_ITEMS + 1) * 7.0));

		selected_item_index = 1;
	}
}

howTo::~howTo()
{

}

void howTo::tutorial()
{
	sf::RenderWindow window(sf::VideoMode(600, 600), "B.O.B Berserk Out Bob");

	howTo menu(window.getSize().x, window.getSize().y);

	sf::Texture texture;
	texture.loadFromFile("pic.jpg");
	sf::Sprite sprite(texture);

	sprite.setScale(1.f, 1.6f);
	sprite.setPosition(0.0f, 0.0f);

	while (window.isOpen())
	{
		sf::Event event;

		while (window.pollEvent(event))
		{
			switch (event.type)
			{
			case sf::Event::KeyReleased:

				switch (event.key.code)
				{

				case sf::Keyboard::Up:
					menu.move_up();
					break;

				case sf::Keyboard::Down:
					menu.move_down();
					break;

				case sf::Keyboard::Return:

					switch (menu.get_pressed_item())
					{

					default:
						window.close();
					}
					break;
				}
				break;

			case sf::Event::Closed:

				window.close();

				break;

			}
		}

		window.clear();

		menu.draw(window);

		window.draw(sprite);

		window.display();

	}
}

void howTo::draw(sf::RenderWindow &window)
{
	for (int i = 0; i < HOW_TO_ITEMS; i++)
	{
		window.draw(menu[i]);
	}
}

void howTo::move_up()
{
	if (selected_item_index - 1 >= 1)
	{
		menu[selected_item_index].setColor(sf::Color::White);
		selected_item_index--;
		menu[selected_item_index].setColor(sf::Color::White);
	}
}

void howTo::move_down()
{
	if (selected_item_index + 1 < HOW_TO_ITEMS)
	{
		menu[selected_item_index].setColor(sf::Color::White);
		selected_item_index++;
		menu[selected_item_index].setColor(sf::Color::White);
	}
}