#pragma once
#include "bob.h"
#include "wolves.h"
#define HOW_TO_ITEMS 7
class howTo
{
public:

	howTo(float width, float height);
	~howTo();
	void tutorial();
	void draw(sf::RenderWindow &window);
	void move_up();
	void move_down();
	int get_pressed_item() { return selected_item_index; }
private:
	int selected_item_index;
	sf::Font font;
	sf::Text menu[HOW_TO_ITEMS];
	//sf::Text title[The_Tiltle];
};