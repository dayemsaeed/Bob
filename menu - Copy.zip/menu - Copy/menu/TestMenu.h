#pragma once
#include "bob.h"
#include "wolves.h"
#define TEST_MENU_ITEMS 7
class TestMenu
{
public:
	TestMenu(float width, float height);
	~TestMenu();

	void draw(sf::RenderWindow &window);
	void move_up();
	void move_down();
	int get_pressed_item() { return selected_item_index; }
private:
	int selected_item_index;
	sf::Font font;
	sf::Text menu[TEST_MENU_ITEMS];
	//sf::Text title[The_Tiltle];
};