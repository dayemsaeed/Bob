//Jiajie Wu
//cpts 122
#include "TestMenu.h"
TestMenu::TestMenu(float width, float height)
{
	if (!font.loadFromFile("arial.ttf"))
	{

	}
	else
	{
		menu[0].setFont(font);
		menu[0].setColor(sf::Color::Red);
		menu[0].setString("Test Menu");
		menu[0].setPosition(sf::Vector2f(width / 4.0, height / (TEST_MENU_ITEMS + 1) * 4.0));

		menu[1].setFont(font);
		menu[1].setColor(sf::Color::Magenta);
		menu[1].setString("Test Gravity");
		menu[1].setPosition(sf::Vector2f(width / 2.5, height / (TEST_MENU_ITEMS + 1) * 4.5));

		menu[2].setFont(font);
		menu[2].setColor(sf::Color::White);
		menu[2].setString("Test Sound");
		menu[2].setPosition(sf::Vector2f(width / 2.5, height / (TEST_MENU_ITEMS + 1) * 5.0));

		menu[3].setFont(font);
		menu[3].setColor(sf::Color::White);
		menu[3].setString("Test Collisions");
		menu[3].setPosition(sf::Vector2f(width / 2.5, height / (TEST_MENU_ITEMS + 1) * 5.5));

		menu[4].setFont(font);
		menu[4].setColor(sf::Color::White);
		menu[4].setString("Test Movement");
		menu[4].setPosition(sf::Vector2f(width / 2.5, height / (TEST_MENU_ITEMS + 1) * 6.0));

		menu[5].setFont(font);
		menu[5].setColor(sf::Color::White);
		menu[5].setString("Test Load Map");
		menu[5].setPosition(sf::Vector2f(width / 2.5, height / (TEST_MENU_ITEMS + 1) * 6.5));

		menu[6].setFont(font);
		menu[6].setColor(sf::Color::White);
		menu[6].setString("Exit");
		menu[6].setPosition(sf::Vector2f(width / 2.5, height / (TEST_MENU_ITEMS + 1) * 7.0));
		
		selected_item_index = 1;
	}
}

TestMenu::~TestMenu()
{

}

void TestMenu::draw(sf::RenderWindow &window)
{
	for (int i = 0; i < TEST_MENU_ITEMS; i++)
	{
		window.draw(menu[i]);
	}
}

void TestMenu::move_up()
{
	if (selected_item_index - 1 >= 1)
	{
		menu[selected_item_index].setColor(sf::Color::White);
		selected_item_index--;
		menu[selected_item_index].setColor(sf::Color::Magenta);
	}
}

void TestMenu::move_down()
{
	if (selected_item_index + 1 < TEST_MENU_ITEMS)
	{
		menu[selected_item_index].setColor(sf::Color::White);
		selected_item_index++;
		menu[selected_item_index].setColor(sf::Color::Magenta);
	}
}