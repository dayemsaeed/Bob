//Jiajie Wu
//cpts 122
#include "header.h"
Menu::Menu(float width, float height) 
{
	if (!font.loadFromFile("arial.ttf"))
	{
	
	}
	else
	{
		menu[0].setFont(font);
		menu[0].setColor(sf::Color::Red);
		menu[0].setString("B.O.B  Berserk Out Bob");
		menu[0].setPosition(sf::Vector2f(width / 4.0, height / (MAX_ITEMS + 1) * 4.0));

		menu[1].setFont(font);
		menu[1].setColor(sf::Color::Magenta);
		menu[1].setString("Play");
		menu[1].setPosition(sf::Vector2f(width / 2.5, height / (MAX_ITEMS + 1) * 4.5));

		menu[2].setFont(font);
		menu[2].setColor(sf::Color::White);
		menu[2].setString("Print Credits to Console");
		menu[2].setPosition(sf::Vector2f(width / 2.5, height / (MAX_ITEMS + 1) * 5.0));
		
		menu[3].setFont(font);
		menu[3].setColor(sf::Color::White);
		menu[3].setString("How To");
		menu[3].setPosition(sf::Vector2f(width / 2.5, height / (MAX_ITEMS + 1) * 5.5));

		menu[4].setFont(font);
		menu[4].setColor(sf::Color::White);
		menu[4].setString("Run Tests");
		menu[4].setPosition(sf::Vector2f(width / 2.5, height / (MAX_ITEMS + 1) * 6.0));

		menu[5].setFont(font);
		menu[5].setColor(sf::Color::White);
		menu[5].setString("Exit");
		menu[5].setPosition(sf::Vector2f(width / 2.5, height / (MAX_ITEMS + 1) * 6.5));
		selected_item_index = 1;
	}
}

Menu::~Menu() 
{

}

void Menu::draw(sf::RenderWindow &window)
{
	for (int i = 0; i < MAX_ITEMS; i++)
	{
		window.draw(menu[i]);
	}
}

void Menu::move_up()
{
	if (selected_item_index - 1 >= 1)
	{
		menu[selected_item_index].setColor(sf::Color::White);
		selected_item_index--;
		menu[selected_item_index].setColor(sf::Color::Magenta);
	}
}

void Menu::move_down()
{
	if (selected_item_index + 1 < MAX_ITEMS-1)
	{
		menu[selected_item_index].setColor(sf::Color::White);
		selected_item_index++;
		menu[selected_item_index].setColor(sf::Color::Magenta);
	}
}

void Menu::howTo()
{

}
