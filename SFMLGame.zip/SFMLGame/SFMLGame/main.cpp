// This code expands on the tutorial code provided at:
// http://www.sfml-dev.org/tutorials/2.3/start-vc.php

#include <Windows.h>
#include "header.h"


int main()
{
	// establish background
	sf::Texture background;
	sf::Sprite distance;

	// load image of background
	if (!background.loadFromFile("spaceBack1.png")) {
		return -1;
	}
	distance.setTexture(background);
	distance.setPosition(-900, 0);

	// platforms + ground
	sf::Texture block;
	sf::Texture * blockPtr = &block; // rectangleShapes need pointers to textures

	if (!block.loadFromFile("rocky01.png")) {
		return -1;
	}

	// water
	sf::Texture water;
	sf::Texture * waterPtr = &water; // rectangleShapes need pointers to textures

	if (!water.loadFromFile("water1.png")) {
		return -1;
	}

	Platform ground[100];
	for (int i = 0; i < 100; i++) {
		if (i > 30 && i < 45) {
			ground[i].setShape(sf::Vector2f(50.f, 50.f));
			ground[i].setTexture(waterPtr);
			ground[i].setPos(-100 + (i * 50), 650);
		} else if (i > 77 && i < 80) {
			ground[i].setShape(sf::Vector2f(50.f, 50.f));
			ground[i].setTexture(waterPtr);
			ground[i].setPos(-100 + (i * 50), 650);
		} else {
			ground[i].setShape(sf::Vector2f(50.f, 50.f));
			ground[i].setTexture(blockPtr);
			ground[i].setPos(-100 + (i * 50), 650);
		}
	}

	Platform one(sf::Vector2f(700, 350), blockPtr, sf::Vector2f(400, 300));
	Platform two(sf::Vector2f(500, 450), blockPtr, sf::Vector2f(250, 200));
	Platform thr(sf::Vector2f(800, 250), blockPtr, sf::Vector2f(300, 400));
	Platform fur(sf::Vector2f(1300, 400), blockPtr, sf::Vector2f(800, 300));
	Platform fiv(sf::Vector2f(2850, 450), blockPtr, sf::Vector2f(800, 150));
	Platform six(sf::Vector2f(2500, 550), blockPtr, sf::Vector2f(300, 100));
	Platform sev(sf::Vector2f(2300, 450), blockPtr, sf::Vector2f(100, 100));
	Platform egt(sf::Vector2f(2700, 550), blockPtr, sf::Vector2f(100, 100));


	Platform allPlats[108];
	allPlats[0] = fur;
	for (int i = 1; i < 101; i++) {
		allPlats[i] = ground[i - 1];
	}
	allPlats[101] = one;
	allPlats[102] = two;
	allPlats[103] = thr;
	allPlats[104] = fiv;
	allPlats[105] = six;
	allPlats[106] = sev;
	allPlats[107] = egt;




	int numPlats = 108;

	// inherent attributes
	double speed = 5.0, fallingSpeed = 7.5;
	double centerX = 500;
	double centerY = 350;
	bool jumping = FALSE;
	bool collision = FALSE;
	std::string const left = "left";
	std::string const right = "right";
	std::string const down = "down";
	std::string const up = "up";

	// character: testing with green rectangle
	sf::RectangleShape rectangle(sf::Vector2f(150, 80));
	rectangle.setFillColor(sf::Color(0, 250, 0)); // green block
	rectangle.setPosition(0, 550);

	// establish window
	sf::View gameBackground(sf::FloatRect(0, 0, 1000.f, 700.f));
	sf::RenderWindow window(sf::VideoMode(1000, 700), "Bob Bro in Space");
	window.setVerticalSyncEnabled(true);
	// character needs a sf::floatRect() representing the sliver that checks for interactions with platforms. 

	// window loop
	while (window.isOpen())
	{
		
		// event loop
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				window.close();

				return 0;
			}
		}

		// Movement
		if (event.type == sf::Event::KeyPressed) {
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
					rectangle.move(0, -speed);
			} else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
				if (!checkCollides(rectangle, allPlats, numPlats, down, speed)) {
					rectangle.move(0, speed);
				}
			} else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
				if (!(rectangle.getPosition().x < (gameBackground.getCenter().x - 500))) {
					rectangle.move(-speed, 0);
				}
			} else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
					rectangle.move(speed, 0);
				if (rectangle.getPosition().x > centerX) {
					centerX += speed;
					distance.move(speed, 0); // background moves with character
				}
			}
		}


		window.clear();
		gameBackground.setCenter(centerX, centerY);
		window.setView(gameBackground);
		window.draw(distance);
		for (int j = 0; j < numPlats; j++) {
			allPlats[j].drawToWindow(window);
		}
		window.draw(rectangle);		
		window.display();

	}


	return 0;
}