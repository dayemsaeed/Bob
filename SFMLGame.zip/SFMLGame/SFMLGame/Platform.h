#include <SFML/Graphics.hpp>

class Platform : public sf::RectangleShape
{
public:
	Platform() {

	}

	Platform(sf::Vector2f placement, sf::Texture * block, sf::Vector2f size) {
		platform.setSize(size);
		platform.setTexture(block);
		platform.setPosition(placement);

	}

	void drawToWindow(sf::RenderWindow & window) {
		window.draw(platform);
	}

	sf::FloatRect getTopBound() {
	
		return sf::FloatRect(platform.getPosition().x, platform.getPosition().y, platform.getGlobalBounds().width, 1.0);
	}

	void setShape(sf::Vector2f newSize) {
		platform.setSize(newSize);
	}

	void setTexture(sf::Texture * newTex) {
		platform.setTexture(newTex);
	}

	void setPos(double blockX, double blockY) {
		platform.setPosition(blockX, blockY);
	}

private:
	sf::RectangleShape platform;

};