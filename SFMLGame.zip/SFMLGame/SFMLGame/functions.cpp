#include "Platform.h"

// false : no collision
// true  : collision
bool checkCollides(sf::RectangleShape character, Platform all[], int &numPlat, std::string const &direction, double &speed) {
	bool success = false;

	for (int i = 0; i < numPlat; i++) {
		if (character.getGlobalBounds().intersects(all[i].getTopBound()))
			success = true;
	}

	return success;
}