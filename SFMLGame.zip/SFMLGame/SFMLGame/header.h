#include "Platform.h"

bool checkCollides(sf::RectangleShape character, Platform all[], int &numPlat, std::string const &direction, double &speed);
