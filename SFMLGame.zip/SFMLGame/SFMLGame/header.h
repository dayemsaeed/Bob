#include "Platform.h"

bool checkCollides(sf::Sprite character, Platform all[], int &numPlat, int const &direction, float &speed);
