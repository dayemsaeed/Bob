#include <iostream>
#include "header.h"

int main()
{

	// establish background
	sf::Texture background;
	sf::Sprite distance;

	// load image of background
	if (!background.loadFromFile("spaceBack1.png")) {
		return -1;
	}
	distance.setTexture(background);
	distance.setPosition(-900, 0);

	// platforms + ground
	sf::Texture block;
	sf::Texture * blockPtr = &block; // rectangleShapes need pointers to textures

	if (!block.loadFromFile("rocky01.png")) {
		return -1;
	}

	// lava
	sf::Texture lava;
	sf::Texture * lavaPtr = &lava; // rectangleShapes need pointers to textures

	if (!lava.loadFromFile("lava 1.png")) {
		return -1;
	}

	Platform ground[150];
	Platform lavaBlock[50];
	int numLava = 50;
	float platPosition = 0;
	
	int i = 0;
	for (i = 0; i < 35; i++) {
		ground[i].setShape(sf::Vector2f(50.f, 50.f));
		ground[i].setTexture(blockPtr);
		ground[i].setPos(-100 + (i * 50), 650);
		ground[i].setDepth(0);
	}
	platPosition = -100 + i * 50;

	int j = 0;
	for (j = 0; j < 10; j++) {
		lavaBlock[j].setShape(sf::Vector2f(50.f, 50.f));
		lavaBlock[j].setTexture(lavaPtr);
		lavaBlock[j].setPos(platPosition += 50, 650);
		lavaBlock[j].setDepth(0);
	}

	for (; i < 85; i++) {
		ground[i].setShape(sf::Vector2f(50.f, 50.f));
		ground[i].setTexture(blockPtr);
		ground[i].setPos(platPosition += 50, 650);
		ground[i].setDepth(0);
	}

	for (; j < 50; j++) {
		lavaBlock[j].setShape(sf::Vector2f(50.f, 50.f));
		lavaBlock[j].setTexture(lavaPtr);
		lavaBlock[j].setPos(platPosition += 50, 650);
		lavaBlock[j].setDepth(0);
	}

	for (; i < 150; i++) {
		ground[i].setShape(sf::Vector2f(50.f, 50.f));
		ground[i].setTexture(blockPtr);
		ground[i].setPos(platPosition += 50, 650);
		ground[i].setDepth(0);
	}

	Platform test(sf::Vector2f(-50, 350), blockPtr, sf::Vector2f(400, 300), 0);
	Platform one(sf::Vector2f(700, 350), blockPtr, sf::Vector2f(400, 300), 0);
	Platform two(sf::Vector2f(500, 450), blockPtr, sf::Vector2f(250, 200), 0);
	Platform thr(sf::Vector2f(800, 250), blockPtr, sf::Vector2f(300, 400), 0);
	Platform fur(sf::Vector2f(1300, 400), blockPtr, sf::Vector2f(800, 300), 0);
	Platform fiv(sf::Vector2f(2850, 450), blockPtr, sf::Vector2f(800, 150), 0);
	Platform six(sf::Vector2f(2500, 550), blockPtr, sf::Vector2f(300, 100), 0);
	Platform sev(sf::Vector2f(2300, 450), blockPtr, sf::Vector2f(100, 100), 0);
	Platform egt(sf::Vector2f(2700, 550), blockPtr, sf::Vector2f(100, 100), 0);
	Platform nne(sf::Vector2f(4400, 600), blockPtr, sf::Vector2f(350, 50), 0);
	Platform ten(sf::Vector2f(4800, 550), blockPtr, sf::Vector2f(130, 50), 0);
	Platform elv(sf::Vector2f(5100, 350), blockPtr, sf::Vector2f(80, 50), 0); // big lava
	Platform tlv(sf::Vector2f(5000, 550), blockPtr, sf::Vector2f(100, 100), 0);
	Platform trt(sf::Vector2f(5800, 450), blockPtr, sf::Vector2f(500, 100), 0);
	Platform frt(sf::Vector2f(6600, 400), blockPtr, sf::Vector2f(100, 100), 0); // end big lava
	Platform fvt(sf::Vector2f(7900, 450), blockPtr, sf::Vector2f(300, 200), 0); 


	Platform allPlats[166];
	allPlats[0] = fur;
	for (int i = 1; i < 151; i++) {
		allPlats[i] = ground[i - 1];
	}
	allPlats[151] = one;
	allPlats[152] = two;
	allPlats[153] = thr;
	allPlats[154] = fiv;
	allPlats[155] = six;
	allPlats[156] = sev;
	allPlats[157] = egt;
	allPlats[158] = nne;
	allPlats[159] = ten;
	allPlats[160] = elv;
	allPlats[161] = tlv;
	allPlats[162] = test;
	allPlats[163] = trt;
	allPlats[164] = frt;
	allPlats[165] = fvt;


	int numPlats = 166;

	// inherent attributes
	double centerX = 500;
	double centerY = 350;

	enum Direction { Down, Left, Right, Up };
	
	// window stuff
	int x_coord = 0, y_coord = Right, x_coord1 = 0, y_coord1 = Right;
	sf::Vector2i source(x_coord, y_coord);
	sf::Vector2i sourceWolves[5];
	float frameCounter = 0, switchFrame = 100, frameSpeed = 500;
	sf::Clock clock;
	sf::View gameBackground(sf::FloatRect(0, 0, 1000.f, 700.f));
	sf::RenderWindow window(sf::VideoMode(1000, 700), "Bob in Space");
	window.setVerticalSyncEnabled(true);

	// bob
	sf::Texture bobTex;
	if (!bobTex.loadFromFile("bob-sheet.png")) {
		return -1;

	}
	
	Bob ourBob(sf::Vector2f(0,0), &bobTex, sf::Vector2f(32,32), 10, 250);

	// wolf
	sf::Texture wolfTex;
	if (!wolfTex.loadFromFile("wolf.png")) {
		return -1;

	}

	wolfTex.setSmooth(true);
	Wolves enemies[15];
	enemies[0] = Wolves(sf::Vector2f(8500,0), &wolfTex, sf::Vector2f(96, 96), 3, 150, true);
	enemies[1] = Wolves(sf::Vector2f(200, 0), &wolfTex, sf::Vector2f(32, 32), 3, 75, false);
	enemies[2] = Wolves(sf::Vector2f(400, 0), &wolfTex, sf::Vector2f(32, 32), 2, 100, true);
	enemies[3] = Wolves(sf::Vector2f(600, 0), &wolfTex, sf::Vector2f(32, 32), 5, 100, true);
	enemies[4] = Wolves(sf::Vector2f(800, 0), &wolfTex, sf::Vector2f(32, 32), 2, 50, false);
	enemies[5] = Wolves(sf::Vector2f(1000, 0), &wolfTex, sf::Vector2f(32, 32), 2, 75, true);

	int numWolves = 6;
	

	// game loop
	while (window.isOpen()) {

		sf::Event event;


		// Bob Movement	- key pressed
		if (event.type == sf::Event::KeyPressed) {
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
				ourBob.move("left", gameBackground, centerX, distance, source);
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
				ourBob.move("right", gameBackground, centerX, distance, source);
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
				ourBob.move("up", gameBackground, centerX, distance, source);
			}
		}

		// Bob gravity + squish
		ourBob.gravity(allPlats, numPlats, source);
		for (int qz = 0; qz < numWolves; qz++) {
			if (ourBob.getPackage().getGlobalBounds().intersects(enemies[qz].getTopBound())) {
				enemies[qz].getPackage().setPosition(-1000, 0);
				std::cout << "Squish!" << std::endl;
			}
		}

		// update Bob Sprite
		frameCounter += frameSpeed * clock.restart().asSeconds();
		if (frameCounter >= switchFrame) {
			frameCounter = 0;
			source.x++;
			if (source.x * 32 >= bobTex.getSize().x) {
				source.x = 0;
			}
		}
		ourBob.setTexture(sf::IntRect(source.x * 32, source.y * 32, 32, 32));

		// event loop
		while (window.pollEvent(event)) {

			switch (event.type) {

			case sf::Event::Closed:
				window.close();
				break;

				// space 'jumping' is released
			case sf::Event::KeyReleased:
				ourBob.setJumping(false); // turns on gravity (more magic!)

			}
		}

		// wolf Movement
		for (int ww = 0; ww < numWolves; ww++) {
			enemies[ww].move("none", gameBackground, centerX, distance, sourceWolves[ww]);
		}

		// wolf Gravity
		for (int h = 0; h < numWolves; h++) {
			enemies[h].gravity(allPlats, numPlats, sourceWolves[h]);
		}

		// check ded
		for (int wwz = 0; wwz < numWolves; wwz++) {
			if (ourBob.getPackage().getGlobalBounds().intersects(enemies[wwz].getMiddle())) {
				centerX = 500;
				distance.setPosition(0, 0); // background moves with character
				ourBob.getPackage().setPosition(0, 0);
				std::cout << "You Lose" << std::endl;
			}
		}

		// check lava
		for (int lvv = 0; lvv < numLava; lvv++) {
			if (ourBob.getPackage().getGlobalBounds().intersects(lavaBlock[lvv].getTopBound())) {
				ourBob.getPackage().setPosition(0, 0);
				centerX = 500;
				distance.setPosition(0,0); // background moves with character
				std::cout << "You Lose" << std::endl;
			}
		}


		// update wolf Sprites
		for (int sw = 0; sw < numWolves; sw++) {
			if (frameCounter >= switchFrame) {
				frameCounter = 0;
				sourceWolves[sw].x++;
				if (sourceWolves[sw].x * 32 >= wolfTex.getSize().x) {
					sourceWolves[sw].x = 0;
				}
			}
			
			enemies[sw].setTexture(sf::IntRect(sourceWolves[sw].x * 32, sourceWolves[sw].y * 32, 32, 32));
		}

		window.clear();
		gameBackground.setCenter(centerX, centerY);
		window.setView(gameBackground);
		window.draw(distance);
		for (int j = 0; j < numPlats; j++) {
			allPlats[j].drawToWindow(window);
		}
		for (int w = 0; w < numWolves; w++) {
			enemies[w].drawToWindow(window);
		}
		for (int la = 0; la < numLava; la++) {
			lavaBlock[la].drawToWindow(window);
		}
		ourBob.drawToWindow(window);
		window.display();

	}

	return 0;
}